// khai báo thư viện express và sử dụng nó
const express = require('express');
const bodyParser= require('body-parser')
const MongoClient = require('mongodb').MongoClient

const app = express();

// Make sure you place body-parser before your CRUD handlers!
app.use(bodyParser.urlencoded({ extended: true }))

// 
app.set('view engine', 'ejs')
// connection string
const connectionString = 'mongodb+srv://khanhkudo02:Khanh150802@cluster0.gimqqtp.mongodb.net/?retryWrites=true&w=majority'

// connect to MongoDB Atlas
MongoClient.connect(connectionString, { useUnifiedTopology: true
})
.then(client => {
    console.log('Connected to Database')

    // kết nối / tạo database 'star-wars-quotes'
    const db = client.db('star-wars-quotes')
    
    // kết nối / tạo collection 'quotes' 
    const quotesCollection = db.collection('quotes')


    // khi client truy cập port 3000 của server, 
    // server sẽ trả về file index.html
    app.get('/', (req, res) => {
    
       // res.sendFile(__dirname + '/index.html')
    
        // Note: __dirname is directory current directory you're in. Try logging it and see what you get!
        // Mine was '/Users/zellwk/Projects/demo-repos/crud-expressmongo' for this app.
        // tim trong database
       // const cursor = db.collection('quotes').find()
      //  console.log(cursor)

        db.collection('quotes').find().toArray()
    .then(results => {
    console.log(results)
    // tao flie index.ejs
    res.render('index.ejs', { quotes: results })
    })
.catch(error => console.error(error))
    })


    // client -> POST -> '/quotes' -> server -> 'Helloooo!' -> console
    app.post('/quotes', (req, res) => {
        quotesCollection.insertOne(req.body)
            .then(result => {
                console.log(result)
                res.redirect('/')
            })
            .catch(error => console.error(error))
    })
    const PORT = process.env.PORT || 3000;
    // server lắng nghe port 3000
    app.listen(PORT, function() {
        console.log('listening on ' + PORT)
    })

})
.catch(error => console.error(error))








